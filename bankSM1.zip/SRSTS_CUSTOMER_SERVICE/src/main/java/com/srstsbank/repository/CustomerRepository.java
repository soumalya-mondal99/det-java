package com.srstsbank.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.srstsbank.entity.CustomerEntity;

@Repository
public interface CustomerRepository extends JpaRepository<CustomerEntity, Integer>{
	//CustomerEntity findByUsername(String name);
	//CustomerEntity findByUserId(Long custId);

}
