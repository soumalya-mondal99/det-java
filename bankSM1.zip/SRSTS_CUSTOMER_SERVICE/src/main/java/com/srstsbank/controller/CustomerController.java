package com.srstsbank.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.srstsbank.dto.LoginRequest;
import com.srstsbank.entity.CustomerEntity;
import com.srstsbank.service.CustomerService;

@RestController
@RequestMapping("/customer")
@CrossOrigin
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	
	private CustomerEntity customerEntity;
	
	
	@GetMapping()
	public String welcome() {
		return "welcome";
	}
//	@GetMapping("/byid/{id}")
//	public Optional<StudentSMEntity> getById(@PathVariable Integer id) {
//		return studentSMService.getOne(id);
//	}
//	@PostMapping("/post")
//	public CustomerEntity create(@RequestBody CustomerEntity customerEntity) {
//		return customerService.create(customerEntity);
//	}
	@PostMapping("/login")
	public CustomerEntity login(@RequestBody LoginRequest loginRequest) {
		Integer i= loginRequest.getCustId();
		if (customerService.authenticate(loginRequest.getCustId(), loginRequest.getPassword())) {
			return (customerService.findByUserId(i));
			//return Optional.ofNullable(customerService.findByCustId(i));
		}else {
			return null;
		}
	}

}
