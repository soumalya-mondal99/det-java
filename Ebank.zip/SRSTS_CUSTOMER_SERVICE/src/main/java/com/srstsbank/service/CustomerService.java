package com.srstsbank.service;

import com.srstsbank.entity.CustomerEntity;

public interface CustomerService {
	
	CustomerEntity create(CustomerEntity customerEntity);

}
