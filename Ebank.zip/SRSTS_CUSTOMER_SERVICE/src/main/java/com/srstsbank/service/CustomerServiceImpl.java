package com.srstsbank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srstsbank.entity.CustomerEntity;
import com.srstsbank.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Override
	public CustomerEntity create(CustomerEntity customerEntity) {
		return customerRepository.save(customerEntity);
	}

}
