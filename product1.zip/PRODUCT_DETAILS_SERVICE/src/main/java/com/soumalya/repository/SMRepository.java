package com.soumalya.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.soumalya.entities.SMEntity;


@Repository
public interface SMRepository extends JpaRepository<SMEntity, Integer>{
	Optional<SMEntity> findByType(String type);

}
