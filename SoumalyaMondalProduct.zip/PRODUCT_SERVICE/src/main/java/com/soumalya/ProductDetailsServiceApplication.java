package com.soumalya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.soumalya.entities.SMEntity;
import com.soumalya.service.SMService;

@SpringBootApplication
@CrossOrigin
public class ProductDetailsServiceApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(ProductDetailsServiceApplication.class, args);
		SMService service = context.getBean(SMService.class);
		service.create(new SMEntity(1,"mobile"));
		service.create(new SMEntity(2,"laptop"));
		service.create(new SMEntity(3,"laptop"));
	}

}
