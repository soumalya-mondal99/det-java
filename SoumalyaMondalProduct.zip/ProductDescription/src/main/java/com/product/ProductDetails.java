package com.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.product.Entity.ProductDetailsEntity;
import com.product.Service.ProductDetailsService;

@SpringBootApplication
public class ProductDetails {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(ProductDetails.class, args);
		ProductDetailsService service = context.getBean(ProductDetailsService.class);
		service.addProduct(new ProductDetailsEntity(1,"mi","note7pro",15000));
		service.addProduct(new ProductDetailsEntity(2,"dell","latitude",30000));
		service.addProduct(new ProductDetailsEntity(3,"lg","random3",6000));
		
	}

}
