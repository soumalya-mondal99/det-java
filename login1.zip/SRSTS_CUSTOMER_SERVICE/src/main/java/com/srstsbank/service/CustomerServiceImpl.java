package com.srstsbank.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srstsbank.entity.CustomerEntity;
import com.srstsbank.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Override
	public CustomerEntity create(CustomerEntity customerEntity) {
		return customerRepository.save(customerEntity);
	}

	@Override
	public boolean findByCustId(Integer custId) {
		// TODO Auto-generated method stub
		return customerRepository.existsById(custId);
	}
	
	@SuppressWarnings("deprecation")
	@Override
	public CustomerEntity findByUserId(Integer custId) {
		// TODO Auto-generated method stub
		return customerRepository.getById(custId);
	}

	@Override
	public boolean authenticate(Integer custId, String password) {
		// TODO Auto-generated method stub
		//Optional<CustomerEntity> customerEntity =findByCustId(custId);
		if (findByCustId(custId)){
			CustomerEntity customerEntity=customerRepository.getById(custId);
			return customerEntity != null && customerEntity.getPassword().equals(password);
		}else {
			return false;
		}
		
	}

}
