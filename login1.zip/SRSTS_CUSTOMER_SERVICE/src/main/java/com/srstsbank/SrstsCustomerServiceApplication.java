package com.srstsbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.srstsbank.entity.CustomerEntity;
import com.srstsbank.service.CustomerService;

@SpringBootApplication
@CrossOrigin
public class SrstsCustomerServiceApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(SrstsCustomerServiceApplication.class, args);
		CustomerService service = context.getBean(CustomerService.class);
		service.create(new CustomerEntity(1,"abc1","Soumalya Mondal","sou@gmail","9800002345"));
		service.create(new CustomerEntity(2,"abc2","Sudipta Sasmal","sudip@gmail","9811112345"));
		service.create(new CustomerEntity(3,"abc3","Rupa Kumari Yadav","rupa@gmail","9800005678"));
		service.create(new CustomerEntity(4,"abc4","Shatabdi Ganguly","sat@gmail","9800230945"));
		service.create(new CustomerEntity(5,"abc5","Tridhara Banarjee","tri@gmail","7896002345"));
	}
	

}
