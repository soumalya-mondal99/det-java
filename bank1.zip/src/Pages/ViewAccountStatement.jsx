import React, { useState } from 'react';

export default function ViewAccountStatement() {
    const [accountNumber, setAccountNumber] = useState('');
 const [fromDate, setFromDate] = useState('');
 const [toDate, setToDate] = useState('');
 const [transactions, setTransactions] = useState([]);
 const [errorMessage, setErrorMessage] = useState('');
 const handleViewStatement = () => {
   // Validate inputs
   if (!accountNumber || !fromDate || !toDate) {
     setErrorMessage('Please fill in all fields');
     return;
   }
   // Perform logic to fetch transactions for the period here
   // For demonstration, just log the input data
   console.log('Account Number:', accountNumber);
   console.log('From Date:', fromDate);
   console.log('To Date:', toDate);
   // Reset error message
   setErrorMessage('');
   // Dummy data for demonstration
   const dummyTransactions = [
     { id: 1, date: '2024-05-01', description: 'Payment', amount: 100 },
     { id: 2, date: '2024-05-05', description: 'Deposit', amount: 500 },
     { id: 3, date: '2024-05-10', description: 'Withdrawal', amount: 200 }
   ];
   // Update transactions state with dummy data
   setTransactions(dummyTransactions);
 };
  return (
    <div>
      <h2>View/Download Account Statement</h2>
     {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
<label>
       Account Number:
<input
         type="text"
         value={accountNumber}
         onChange={(e) => setAccountNumber(e.target.value)}
       />
</label>
<br />
<label>
       From Date:
<input
         type="date"
         value={fromDate}
         onChange={(e) => setFromDate(e.target.value)}
       />
</label>
<br />
<label>
       To Date:
<input
         type="date"
         value={toDate}
         onChange={(e) => setToDate(e.target.value)}
       />
</label>
<br />
<button onClick={handleViewStatement}>View Statement</button>
     {/* Display transactions */}
<h3>Transactions:</h3>
<table>
<thead>
<tr>
<th>ID</th>
<th>Date</th>
<th>Description</th>
<th>Amount</th>
</tr>
</thead>
<tbody>
         {transactions.map((transaction) => (
<tr key={transaction.id}>
<td>{transaction.id}</td>
<td>{transaction.date}</td>
<td>{transaction.description}</td>
<td>{transaction.amount}</td>
</tr>
         ))}
</tbody>
</table>
    </div>
  )
}
