import React, { useState } from 'react';

export default function FundTransfer() {
    const [sourceAccount, setSourceAccount] = useState('');
    const [destinationAccount, setDestinationAccount] = useState('');
    const [amount, setAmount] = useState('');
    const [transactionPassword, setTransactionPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const handleTransfer = () => {
      // Validate input fields
      if (!sourceAccount || !destinationAccount || !amount || !transactionPassword) {
        setErrorMessage('Please fill in all fields');
        return;
      }
      // Perform fund transfer logic here
      // For demonstration, just log the transfer details
      console.log('Transfer details:');
      console.log('Source Account:', sourceAccount);
      console.log('Destination Account:', destinationAccount);
      console.log('Amount:', amount);
      console.log('Transaction Password:', transactionPassword);
      // Reset input fields and error message
      setSourceAccount('');
      setDestinationAccount('');
      setAmount('');
      setTransactionPassword('');
      setErrorMessage('');
    };
  return (
    <div>
      <h2>Fund Transfer</h2>
     {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
<label>
       Source Account Number:
<input
         type="text"
         value={sourceAccount}
         onChange={(e) => setSourceAccount(e.target.value)}
       />
</label>
<br />
<label>
       Destination Account Number:
<input
         type="text"
         value={destinationAccount}
         onChange={(e) => setDestinationAccount(e.target.value)}
       />
</label>
<br />
<label>
       Amount to Transfer:
<input
         type="text"
         value={amount}
         onChange={(e) => setAmount(e.target.value)}
       />
</label>
<br />
<label>
       Transaction Password:
<input
         type="password"
         value={transactionPassword}
         onChange={(e) => setTransactionPassword(e.target.value)}
       />
</label>
<br />
<button onClick={handleTransfer}>Transfer</button>
    </div>
  )
}
