package com.soumalya.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.soumalya.dto.StudentDTO;
import com.soumalya.entity.StudentEntity;
import com.soumalya.service.StudentService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping
@CrossOrigin
@Slf4j
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	@PostMapping("/student/addstudent")
	public String addStudent(@RequestBody StudentDTO student) {
		log.info("In Service : {}", student);
		studentService.addStudent(student);
		return "Your Record is Saved : " + student.getName();
	}
	@DeleteMapping("/student/{id}")
	public String deleteStudent(@PathVariable Integer id) {
		log.info("In Service : {}", id);
		
		
		
		if(studentService.deleteStudent(id)) {
			return "Your Record is deleted  : " + id ;
		}else {
			return "Your Record is Not deleted  : " + id ;
		}
	}
	//////
	@PutMapping
	public void updateStudent(@RequestBody StudentDTO dto) {
		
	}
	
	///
	@GetMapping("/student/{id}")
	public Optional<StudentEntity> checkId(@PathVariable("id") Integer id) {
		if(studentService.verifyById(id) != null) {
			
			return studentService.verifyById(id); // id available
		}
		return studentService.verifyById(id); // id not available
	}
	
	@GetMapping("getbyid/{id}")
	public void getStudentById(@PathVariable("id") Integer id) {
		
	}
	@GetMapping("/student/allstudents")
	public List<StudentEntity> getEveryStudents() {
		return studentService.getAll();
		
	}
	/////
	@GetMapping("/student/getstudentbycity/{city}")
	public List<StudentEntity> checkCity(@PathVariable("city") String city) {
		if(studentService.verifyByCity(city) != null) {
			return studentService.verifyByCity(city);  //city available
		}
		return studentService.verifyByCity(city);		//city not available
	}
}
