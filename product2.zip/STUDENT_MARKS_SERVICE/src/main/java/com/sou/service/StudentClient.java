package com.sou.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.sou.vo.StudentVO;



@FeignClient(name="STUDENT-DETAILS-SERVICE")
public interface StudentClient {
	
	@GetMapping("/student/byid/{id}")
	public StudentVO getStudent(@PathVariable Integer id); 
	
}
