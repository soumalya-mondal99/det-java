package com.sou.vo;

import java.io.Serializable;

import com.sou.entity.MarksSMEntity;

import lombok.Data;

@Data
public class StudentMarksVO implements Serializable{
	
	private MarksSMEntity marksSMEntity;
	private StudentVO studentVO;

}
