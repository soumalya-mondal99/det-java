import { Outlet, Link } from "react-router-dom";

function Layout ()  {
  return (
    <>
      <nav>
        
          <button><Link to="/">Home</Link></button>
          {/* <Link to="/login"></Link> */}
          {/* <button><Link to="/fixeddeposit">OpenFixedDeposit</Link></button> */}
          <button><Link to="/transactiondetails">TransactionDetails</Link></button>
          {/* <button><Link to="/updateprofile">UpdateUserProfile</Link></button> */}
          <button> <Link to="/viewtransaction">ViewTransactionDetails</Link></button>
          {/* <button> <Link to="/addbeneficiary">AddNewBeneficiary</Link></button>
          <button> <Link to="/viewbeneficiary">ViewBeneficiaryDetails</Link></button> */}
          <button> <Link to="/fundtransfer">FundTransfer</Link></button>
          {/* <button> <Link to="/changeuserpass">ChangeUserPassword</Link></button> */}
          {/* <button> <Link to="/changetransactionpass">ChangeTransactionPassword</Link></button> */}
          {/* <button><Link to="/logout">LogOut</Link></button> */}
            
          
        
      </nav>

      <Outlet />
    </>
  );
}
 export default Layout;