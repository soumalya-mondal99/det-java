import { useEffect, useState } from "react";


function AccountDetails(props){
  
  const [loading, setLoading] = useState(false);
  console.log(props)
    var temp = props.custid
  

    const [accounts, setAccounts]= useState([]);
    var url="http://172.19.5.235:2223/accounts/allaccount/"+props.custid;
    useEffect(()=>{
      
      if (temp){
        fetch(url, {
      
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        })
          .then((response) => response.json())
          .then((data) => {
            console.table(data);
            setAccounts(data);
          })}

      },[temp])

    

    return (
        <div id="accountDetails" style={{border:'1px solid black'}}>
            <h2>My Accounts</h2>
            <table style={{border: '1px solid black',tableLayout: 'fixed'}}><thead><tr>
              <th >Account No</th><th>Type</th><th>Balance</th>
            </tr></thead>
            <tbody>
            {accounts.map((p, index) => (
                <tr key={index}><td>{p.id}</td><td>{p.accountType}</td><td>{p.balance}</td></tr>
            ))}
            </tbody>
            </table>
      

        </div>
    
    
    );
  }
  
  export default AccountDetails;