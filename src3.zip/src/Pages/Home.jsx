import { Link } from "react-router-dom";
import Login from "./Login";






function Home ()  {
    return (<div><h3>Welcome to the E-Banking System App</h3>
    <Login/></div>);
  }
  
  export default Home;

// import { useState } from "react";
// function Home(){
//   const [serverMessage,setServerMessage]=useState("Waiting.........");
//   const callAPI=()=>{
//     fetch("http://localhost:8080").then((Response)=>Response.text()).then((data)=>{setServerMessage(data);})
//   };
  

//   return(
//     <div style={{color:"red"}}>
//     <h1>This is Home</h1>
//     <button onClick={callAPI}>Call Student API</button>
//     <div>
//     <p>Message from ApI: {serverMessage}</p>
//     </div>
//     </div>
//   );
// }
// export default Home;