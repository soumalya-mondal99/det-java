import React, { useState, useEffect } from 'react';

export default function TransactionDetails({ accountNumber }) {
    const [transactions, setTransactions] = useState([]);
 // Dummy data for demonstration
 useEffect(() => {
   // Assuming you fetch the transaction data from an API based on the account number
   // Replace this with your actual API call
   const fetchTransactions = async () => {
     // Simulating API call delay with setTimeout
     setTimeout(() => {
       // Dummy transaction data
       const dummyData = [
         { sno: 1, date: '2024-05-10', description: 'Grocery shopping', type: 'Debit', amount: 50 },
         { sno: 2, date: '2024-05-09', description: 'Salary deposit', type: 'Credit', amount: 2000 },
         { sno: 3, date: '2024-05-08', description: 'Online payment', type: 'Debit', amount: 100 }
       ];
       setTransactions(dummyData);
     }, 1000); // Simulating 1 second delay
   };
   fetchTransactions();
 }, [accountNumber]);
  return (
    <div>
      <h2>Transaction Details</h2>
<p>Account Number: {accountNumber}</p>
<table>
<thead>
<tr>
<th>Sno</th>
<th>Date</th>
<th>Description</th>
<th>Dr/Cr</th>
<th>Transaction Amount</th>
</tr>
</thead>
<tbody>
         {transactions.map((transaction, index) => (
<tr key={index}>
<td>{transaction.sno}</td>
<td>{transaction.date}</td>
<td>{transaction.description}</td>
<td>{transaction.type}</td>
<td>{transaction.amount}/-</td>
</tr>
         ))}
</tbody>
</table>
    </div>
  )
}
