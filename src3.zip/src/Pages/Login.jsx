import React, { useState } from 'react';
import FundTransfer from './FundTransfer';
import TransactionDetails from './Transaction';
import ViewAccountStatement from './ViewAccountStatement';
import AccountDetails from './AccountDetails';

export default function Login() {
  var isLoggedIn = false;
  
  // const [serverMessage, setServerMessage] = useState("");
  //   const [username, setUsername] = useState('');
    const [key, setKey] = useState({ custId: 0, password: ""});
//  const [password, setPassword] = useState('');
 const [errorMessage, setErrorMessage] = useState('');

 const getDerivedStateFromProps = (p) => {
  console.log("getDerivedStateFromProps loaded");
};
const componentDidMount = () => {
  console.log("Loaded");
};

 const callAuthenticate = (e) => {
  
  e.preventDefault();
  fetch("http://172.19.5.235:2222/customer/login", {

    method: "POST",
   
    body: JSON.stringify(key),
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
    },
  })
  // .then(response => response.json())
  // .then(json => console.log(json))
  // .catch(error => console.log('Failed: ' + errorMessage));

    .then((response) => response.text())
    .then((data) => {
      console.log(data);
      if (data != []){
        console.log(key.custId)
        successful();
        
      }else {setErrorMessage('enter valid userid and password')}
      
      setServerMessage(data);
    }).catch(error => console.log(errorMessage));

    
};
///
const updateId = (e) => {
  const kk = e.target.name;
  const val = e.target.value;
  console.log(kk + " : " + val);
  setKey((values) => ({ ...values, [kk]: val }));
};

const updatePassword = (e) => {
  const kk = e.target.name;
  const val = e.target.value;
  console.log(kk + " : " + val);
  setKey((values) => ({ ...values, [kk]: val }));
};
////
function successful(){
  document.getElementById("login").style.display="none"
  document.getElementById("mainApp").style.display="block"
  isLoggedIn=true

  
}


 const handleSubmit = (e) => {
  
   //e.preventDefault();
  //  if (username && password) {
  //    setUsername('');
  //    setPassword('');
  //    setErrorMessage('');
  //  } else {
  //    setErrorMessage('Wrong userid or password');
  //  }
 };
  return (
    <div>
    <div id='login' style={{display:'block',border:'1px solid black'}}>
      <h2>Login</h2>
     {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
<form onSubmit={callAuthenticate} >
<label>
         UserId:
<input
           type="number"
           value={key.custId}
           onChange={updateId}
           name="custId"
         />
</label>
<br />
<label>
         Password:
<input
           type="password"
           value={key.password}
           onChange={updatePassword}
           name="password"
         />
</label>
<br />
<button type="submit">Login</button>
</form>
    </div>

    <div id='mainApp' style={{display:'none'}}>
      <AccountDetails custid={key.custId}/>
      <FundTransfer/>
      <TransactionDetails/>
      <ViewAccountStatement/>

    </div>

    {/* {isLoggedIn ?  : <p></p>} */}
    
   
    </div>
  );
}


