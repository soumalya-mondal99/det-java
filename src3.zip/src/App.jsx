import { useState } from 'react'

import './App.css'

import Home from "./Pages/Home";
import Layout from "./Pages/Layout";

 
import NoPage from "./Pages/NoPage";
import { BrowserRouter, Route, Routes } from 'react-router-dom';



 
function App() {
 
  return (
    <div>
      <Home/>
       {/* <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
          <Route path="login" element={<Login/>} /> */}
          
          {/* <Route path="transactiondetails" element={<TransactionDetails />} />
          <Route path="viewtransaction" element={<ViewAccountStatement />} />
     
          <Route path="fundtransfer" element={<FundTransfer />} />
     
          <Route path="*" element={<NoPage />} /> */}
        {/* </Route>
      </Routes>
      </BrowserRouter> */}
   
    </div>
  )
}
export default App;
