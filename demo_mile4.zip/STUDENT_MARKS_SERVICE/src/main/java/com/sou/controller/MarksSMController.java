package com.sou.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sou.entity.MarksSMEntity;
import com.sou.service.MarksSMService;



@RestController
@RequestMapping("/marks")
@CrossOrigin
@EnableMethodSecurity
public class MarksSMController {
	
	@Autowired
	private MarksSMService marksSMService;
	
	@PostMapping
	public MarksSMEntity create(@RequestBody MarksSMEntity marksSMEntity) {
		return marksSMService.createMarks(marksSMEntity);
	}
	
//	@GetMapping
//	@Secured("ROLE_ADMIN")
//	public List<EmployeeEntity> getAll(){
//		return employeeService.getAll();
//	}
	
	@GetMapping("/byid/{id}")
//	@Secured("ROLE_USER")
	public MarksSMEntity getOne(@PathVariable Integer id) {
		
		return marksSMService.getByidSM(id);
	}
////	
//	@GetMapping("/getempwithdept/{empId}")
//	public EmployeeDepartmentVO getEmployeeWithDepartment(@PathVariable Integer empId) {
//		return employeeService.getEmployeeWithDepartmentInfoWithFeign(empId);
//	}
//	
//	@GetMapping("bydeptid/{deptId}")
//	public List<EmployeeEntity> getDepartmentById(@PathVariable Integer deptId){
//		return employeeService.getByDeptId(deptId);
//	}
}
