package com.sou.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sou.entity.MarksSMEntity;

@Repository
public interface MarksSMRepository extends JpaRepository<MarksSMEntity, Integer>{
	//List<MarksSMEntity> findBy(Integer deptId);
}
