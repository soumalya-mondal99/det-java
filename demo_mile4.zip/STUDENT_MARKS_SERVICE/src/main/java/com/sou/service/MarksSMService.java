package com.sou.service;

import java.util.Optional;

import com.sou.entity.MarksSMEntity;
import com.sou.vo.StudentMarksVO;


public interface MarksSMService {
	
	public MarksSMEntity createMarks(MarksSMEntity marksSMEntity);
//	public List<EmployeeEntity> getAll();
//	public EmployeeEntity getOne(Integer empId);
	public MarksSMEntity getByidSM(Integer id); 
	//public StudentMarksVO getEmployeeWithDepartmentInfo(Integer empId);
	public StudentMarksVO getMarksWithStudentInfo(Integer idSM) ;
	StudentMarksVO getMarksWithStudentInfoFeign(Integer id);
	
	//EmployeeDepartmentVO getEmployeeWithDepartmentInfoWithFeign(Integer empId);
}
