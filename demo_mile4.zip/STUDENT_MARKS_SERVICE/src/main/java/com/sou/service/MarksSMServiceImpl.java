package com.sou.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sou.entity.MarksSMEntity;
import com.sou.repository.MarksSMRepository;

import com.sou.vo.StudentMarksVO;
import com.sou.vo.StudentVO;

@Service
public class MarksSMServiceImpl implements MarksSMService {

	@Autowired
	private MarksSMRepository marksSMRepository;
	
	@Autowired
	private StudentClient studentClient;


//	@Override
//	public List<EmployeeEntity> getAll() {
//		return employeeRepository.findAll();
//	}

//	@Override
//	public EmployeeEntity getOne(Integer empId) {
//		Optional<EmployeeEntity> optional= employeeRepository.findById(empId);
//		if(optional.isPresent()){
//			return optional.get();
//		}else {
//			return null;
//		}
//	}
	//////////
//	@Override
//	public EmployeeDepartmentVO getEmployeeWithDepartmentInfo(Integer empId) {
////		Optional<EmployeeEntity> optional= employeeRepository.findById(empId);
////		if(optional.isPresent()) {
////			EmployeeEntity employeeEntity =	optional.get();
////			Integer deptId = employeeEntity.getDeptId();
////			String urlGET = "http://localhost:2222/department/byid/"+deptId;   // endpoint
////			//HttpClient //RestClient //RestTemplate //WebClient // Spring- Feign Client
////			RestTemplate restTemplate = new RestTemplate();
////			DepartmentVO departmentVO = restTemplate.getForObject(urlGET, DepartmentVO.class);
////			EmployeeDepartmentVO edVO = new EmployeeDepartmentVO();
////			edVO.setEmployeeEntity(employeeEntity);
////			edVO.setDepartmentVO(departmentVO);
////			
////			return edVO;
////		}
//		return null;
//	}
	
//	@Override
//	public EmployeeDepartmentVO getEmployeeWithDepartmentInfoWithFeign(Integer empId) {
//		Optional<EmployeeEntity> optional= employeeRepository.findById(empId);
//		if(optional.isPresent()) {
//			EmployeeEntity employeeEntity =	optional.get();
//			Integer deptId = employeeEntity.getDeptId();
//			DepartmentVO departmentVO = departmentClient.getDepartment(deptId);
//			EmployeeDepartmentVO edVO = new EmployeeDepartmentVO();
//			edVO.setEmployeeEntity(employeeEntity);
//			edVO.setDepartmentVO(departmentVO);
//			return edVO;
//		}
//		return null;
//	}

	@Override
	public MarksSMEntity createMarks(MarksSMEntity marksSMEntity) {
		return marksSMRepository.save(marksSMEntity);
	}

	@Override
	public MarksSMEntity getByidSM(Integer id) {
		Optional<MarksSMEntity> optional= marksSMRepository.findById(id);
		if(optional.isPresent()){
			return optional.get();
		}else {
			return null;
		}
	}

	@Override
	public StudentMarksVO getMarksWithStudentInfo(Integer idSM) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StudentMarksVO getMarksWithStudentInfoFeign(Integer id) {
		Optional<MarksSMEntity> optional= marksSMRepository.findById(id);
		if(optional.isPresent()) {
			MarksSMEntity marksEntity =	optional.get();
			Integer idSM =marksEntity.getMarks();
			StudentVO studentVO = studentClient.getStudent(idSM);
			StudentMarksVO emVO= new StudentMarksVO();
			emVO.setMarksSMEntity(marksEntity);
			emVO.setStudentVO(studentVO);
//			DepartmentVO departmentVO = departmentClient.getDepartment(deptId);
//			EmployeeDepartmentVO edVO = new EmployeeDepartmentVO();
//			edVO.setEmployeeEntity(employeeEntity);
//			edVO.setDepartmentVO(departmentVO);
			return emVO;
		}
		return null;

	}
	

//	@Override
//	public List<EmployeeEntity> getByDeptId(Integer deptId) {
//		return employeeRepository.findByDeptId(deptId);
//	}

}
