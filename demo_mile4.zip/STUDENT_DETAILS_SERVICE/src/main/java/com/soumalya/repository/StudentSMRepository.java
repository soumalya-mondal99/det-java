package com.soumalya.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.soumalya.entities.StudentSMEntity;


@Repository
public interface StudentSMRepository extends JpaRepository<StudentSMEntity, Integer>{

}
