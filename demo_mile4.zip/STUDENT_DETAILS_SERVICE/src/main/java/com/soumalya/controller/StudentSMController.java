package com.soumalya.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.soumalya.entities.StudentSMEntity;
import com.soumalya.service.StudentSMService;



@RestController
@RequestMapping("/student")
@CrossOrigin
public class StudentSMController {

	@Autowired
	private StudentSMService studentSMService;

	@GetMapping("/byid/{id}")
	public Optional<StudentSMEntity> getById(@PathVariable Integer id) {
		return studentSMService.getOne(id);
	}
	
	@GetMapping("/bylname/{lname}")
	public Optional<StudentSMEntity> getByLname(@PathVariable String lname){
		return studentSMService.getLname(lname);
	}
	
	@PostMapping
	public StudentSMEntity createSM(@RequestBody StudentSMEntity studentSMEntity) {
		return studentSMService.create(studentSMEntity);
	}

}
