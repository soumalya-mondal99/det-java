package com.soumalya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentDetailsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentDetailsServiceApplication.class, args);
	}

}
