package com.soumalya.service;

import java.util.Optional;

import com.soumalya.entities.StudentSMEntity;

public interface StudentSMService {
	
	StudentSMEntity create(StudentSMEntity studentSMEntity);
	Optional<StudentSMEntity> getOne(Integer id);
	Optional<StudentSMEntity> getLname(String lname);
	
//	List<DepartmentEntity> getAll();

}
