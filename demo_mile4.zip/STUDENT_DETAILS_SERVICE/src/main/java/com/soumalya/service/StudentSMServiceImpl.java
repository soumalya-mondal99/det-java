package com.soumalya.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soumalya.entities.StudentSMEntity;
import com.soumalya.repository.StudentSMRepository;


@Service
public class StudentSMServiceImpl implements StudentSMService{
	
	@Autowired
	private StudentSMRepository studentSMRepository;

	@Override
	public StudentSMEntity create(StudentSMEntity studentSMEntity) {
		return studentSMRepository.save(studentSMEntity);
	}

	@Override
	public Optional<StudentSMEntity> getOne(Integer id) {
		return studentSMRepository.findById(id);
	}

	@Override
	public Optional<StudentSMEntity> getLname(String lname) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public StudentSMEntity create(StudentSMEntity ) {
//		return departmentRepository.save(departmentEntity);
//	}
//
//	@Override
//	public DepartmentEntity getOne(Integer deptId) {
//		return departmentRepository.findById(deptId).orElseThrow(()-> new RuntimeException("No Department found with id "+ deptId));
//	}
//
//	@Override
//	public List<DepartmentEntity> getAll() {
//		return departmentRepository.findAll();
//	}

}
